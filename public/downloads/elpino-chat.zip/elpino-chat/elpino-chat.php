<?php
/**
 * Plugin Name:       Elpino Chat
 * Description:       Adds the Elpino AI chat widget to your site and, with WooCommerce, lets it answer order questions.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Elpino
 * License:           GPL-2.0-or-later
 * Text Domain:       elpino-chat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Overridable in wp-config.php for staging/local installs.
if ( ! defined( 'ELPINO_APP_URL' ) ) {
	define( 'ELPINO_APP_URL', 'https://elpino.chat' );
}
if ( ! defined( 'ELPINO_TAG_URL' ) ) {
	define( 'ELPINO_TAG_URL', 'https://cdn.elpino.chat/tag.js' );
}

const ELPINO_OPTION_SITE_KEY = 'elpino_chat_site_key';
const ELPINO_PAGE_SLUG       = 'elpino-chat';

/** A stored site key is only ever the public widget key; anything else is dropped. */
function elpino_chat_clean_key( $value ) {
	$value = is_string( $value ) ? trim( $value ) : '';
	return preg_match( '/^rz_site_[A-Za-z0-9]{8,64}$/', $value ) ? $value : '';
}

function elpino_chat_settings_url( array $args = array() ) {
	return add_query_arg( array_merge( array( 'page' => ELPINO_PAGE_SLUG ), $args ), admin_url( 'options-general.php' ) );
}

// ---- The widget ----------------------------------------------------------

add_action( 'wp_enqueue_scripts', function () {
	$key = elpino_chat_clean_key( get_option( ELPINO_OPTION_SITE_KEY, '' ) );
	if ( '' === $key ) {
		return;
	}
	// Version-less on purpose: tag.js is served from Elpino's CDN and updates itself.
	wp_enqueue_script( 'elpino-chat', ELPINO_TAG_URL, array(), null, true ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
} );

add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	if ( 'elpino-chat' !== $handle ) {
		return $tag;
	}
	$key = elpino_chat_clean_key( get_option( ELPINO_OPTION_SITE_KEY, '' ) );
	return sprintf(
		'<script src="%s" data-site-key="%s" async></script>' . "\n",
		esc_url( ELPINO_TAG_URL ),
		esc_attr( $key )
	);
}, 10, 2 );

// ---- Connect / disconnect ------------------------------------------------

add_action( 'admin_menu', function () {
	add_options_page( __( 'Elpino Chat', 'elpino-chat' ), __( 'Elpino Chat', 'elpino-chat' ), 'manage_options', ELPINO_PAGE_SLUG, 'elpino_chat_render_page' );
} );

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( elpino_chat_settings_url() ) . '">' . esc_html__( 'Settings', 'elpino-chat' ) . '</a>' );
	return $links;
} );

/**
 * Elpino's /connect/wordpress page sends the admin back to return_url with
 * &elpino_website_id=<public key> added. return_url carries a nonce we made, so a
 * link someone else crafted can't change this site's widget.
 */
add_action( 'admin_init', function () {
	if ( ! isset( $_GET['page'] ) || ELPINO_PAGE_SLUG !== $_GET['page'] ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}

	if ( isset( $_GET['elpino_website_id'] ) ) {
		if ( ! current_user_can( 'manage_options' ) || ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'elpino_connect' ) ) {
			wp_die( esc_html__( 'This connect link has expired. Go back to Elpino Chat settings and try again.', 'elpino-chat' ), '', array( 'response' => 403 ) );
		}
		$key = elpino_chat_clean_key( wp_unslash( $_GET['elpino_website_id'] ) );
		if ( '' === $key ) {
			wp_safe_redirect( elpino_chat_settings_url( array( 'elpino_status' => 'invalid' ) ) );
			exit;
		}
		update_option( ELPINO_OPTION_SITE_KEY, $key );
		wp_safe_redirect( elpino_chat_settings_url( array( 'elpino_status' => 'connected' ) ) );
		exit;
	}

	if ( isset( $_GET['elpino_disconnect'] ) ) {
		if ( ! current_user_can( 'manage_options' ) || ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'elpino_disconnect' ) ) {
			wp_die( esc_html__( 'This link has expired. Go back and try again.', 'elpino-chat' ), '', array( 'response' => 403 ) );
		}
		delete_option( ELPINO_OPTION_SITE_KEY );
		wp_safe_redirect( elpino_chat_settings_url( array( 'elpino_status' => 'disconnected' ) ) );
		exit;
	}
} );

function elpino_chat_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$key       = elpino_chat_clean_key( get_option( ELPINO_OPTION_SITE_KEY, '' ) );
	$connected = '' !== $key;
	$status    = isset( $_GET['elpino_status'] ) ? sanitize_key( wp_unslash( $_GET['elpino_status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

	$connect_url = add_query_arg(
		array(
			// add_query_arg() URL-encodes values itself; wp_nonce_url() would HTML-escape the & in the URL.
			'return_url' => add_query_arg( '_wpnonce', wp_create_nonce( 'elpino_connect' ), elpino_chat_settings_url() ),
			'site_url'   => home_url(),
		),
		trailingslashit( ELPINO_APP_URL ) . 'connect/wordpress'
	);
	$disconnect_url = wp_nonce_url( elpino_chat_settings_url( array( 'elpino_disconnect' => 1 ) ), 'elpino_disconnect' );
	$woo_url        = add_query_arg( 'siteUrl', home_url(), trailingslashit( ELPINO_APP_URL ) . 'api/woocommerce/start' );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Elpino Chat', 'elpino-chat' ); ?></h1>

		<?php if ( 'connected' === $status ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Connected. The chat widget is now live on your site.', 'elpino-chat' ); ?></p></div>
		<?php elseif ( 'disconnected' === $status ) : ?>
			<div class="notice notice-info is-dismissible"><p><?php esc_html_e( 'Disconnected. The chat widget has been removed from your site.', 'elpino-chat' ); ?></p></div>
		<?php elseif ( 'invalid' === $status ) : ?>
			<div class="notice notice-error is-dismissible"><p><?php esc_html_e( 'Elpino sent back something we did not recognise. Please try connecting again.', 'elpino-chat' ); ?></p></div>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Chat widget', 'elpino-chat' ); ?></h2>
		<?php if ( $connected ) : ?>
			<p><?php esc_html_e( 'Your site is connected to Elpino and the chat widget is showing on every page.', 'elpino-chat' ); ?></p>
			<p>
				<a class="button" href="<?php echo esc_url( trailingslashit( ELPINO_APP_URL ) . 'dashboard' ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open Elpino dashboard', 'elpino-chat' ); ?></a>
				<a class="button" href="<?php echo esc_url( $disconnect_url ); ?>"><?php esc_html_e( 'Disconnect', 'elpino-chat' ); ?></a>
			</p>
		<?php else : ?>
			<p><?php esc_html_e( 'Link this site to your Elpino account to add the chat widget. You will sign in to Elpino and come straight back.', 'elpino-chat' ); ?></p>
			<p><a class="button button-primary" href="<?php echo esc_url( $connect_url ); ?>"><?php esc_html_e( 'Connect to Elpino', 'elpino-chat' ); ?></a></p>
		<?php endif; ?>

		<?php if ( class_exists( 'WooCommerce' ) ) : ?>
			<hr />
			<h2><?php esc_html_e( 'WooCommerce orders', 'elpino-chat' ); ?></h2>
			<p><?php esc_html_e( 'Let the AI look up order status and tracking for verified customers. WooCommerce will ask you to approve the connection; no keys to copy.', 'elpino-chat' ); ?></p>
			<p><a class="button" href="<?php echo esc_url( $woo_url ); ?>"><?php esc_html_e( 'Connect WooCommerce orders', 'elpino-chat' ); ?></a></p>
			<?php if ( 0 !== strpos( home_url(), 'https://' ) ) : ?>
				<p class="description"><?php esc_html_e( 'WooCommerce only shares order access over https. Enable https on your site first.', 'elpino-chat' ); ?></p>
			<?php endif; ?>
		<?php endif; ?>
	</div>
	<?php
}
