=== Elpino Chat ===
Contributors: elpino
Tags: chat, ai, support, woocommerce, live chat
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add the Elpino AI chat widget to your site, and let it answer WooCommerce order questions.

== Description ==

Connect your site to Elpino in one click and the chat widget appears on every page. With WooCommerce installed, approve one screen and the AI can look up order status and tracking for verified customers; there are no API keys to copy.

This plugin loads a script from Elpino's servers (cdn.elpino.chat) on your public pages, and sends visitors' chat messages to Elpino. See https://elpino.chat/privacy.

== Installation ==

1. Upload the plugin and activate it.
2. Go to Settings > Elpino Chat and choose Connect to Elpino.
3. Sign in to Elpino. You'll be returned here with the widget live.

== Changelog ==

= 1.0.0 =
* First release.
